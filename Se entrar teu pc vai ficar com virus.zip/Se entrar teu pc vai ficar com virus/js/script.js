document.getElementById('formularioHabito').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const habitName = document.getElementById('nomeHabito').value;
    const habitFrequency = document.getElementById('frequenciaHabito').value;
    const habitGoal = document.getElementById('metaHabito').value;


    const listItem = document.createElement('li');
    listItem.textContent = `${habitName} - ${habitFrequency} - Meta: ${habitGoal}`;
    listItem.classList.add('list-group-item', 'fade-in');  // Adiciona a classe fade-in para animação
    

    document.getElementById('listaHabitos').appendChild(listItem);


    document.getElementById('formularioHabito').reset();
});


document.getElementById('listaHabitos').addEventListener('click', function(event) {
    if (event.target.tagName === 'LI') {
        event.target.classList.toggle('concluido');  
    }
});

const style = document.createElement('style');
style.innerHTML = `
    .fade-in {
        opacity: 0;
        animation: fadeIn 1s forwards;
    }

    @keyframes fadeIn {
        to {
            opacity: 1;
        }
    }

    .concluido {
        text-decoration: line-through;
        background-color: #d4edda; /* Fundo verde claro */
        color: #155724; /* Texto verde escuro */
    }
`;
document.head.appendChild(style);
